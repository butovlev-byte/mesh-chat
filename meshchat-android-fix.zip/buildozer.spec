[app]
# Название приложения
title = MeshChat

# Имя пакета
package.name = meshchat

# Домен пакета (должен быть уникальным)
package.domain = org.meshchat

# Исходная директория
source.dir = src

# Расширения файлов для включения
source.include_exts = py,png,jpg,kv,atlas,ttf,json,txt,xml

# Версия приложения
version = 1.0.0

# Требования (зависимости)
requirements = python3,kivy==2.3.0,kivymd==1.2.0,pyjnius,bleak,cryptography,pycryptodome

# Ориентация
orientation = portrait

# Полноэкранный режим
fullscreen = 0

# Android API
android.api = 33
android.minapi = 21
android.sdk = 33
android.ndk = 25b

# Разрешения Android
android.permissions = INTERNET,BLUETOOTH,BLUETOOTH_ADMIN,BLUETOOTH_SCAN,BLUETOOTH_CONNECT,BLUETOOTH_ADVERTISE,ACCESS_FINE_LOCATION,ACCESS_COARSE_LOCATION,READ_CONTACTS,READ_PHONE_STATE,FOREGROUND_SERVICE,WAKE_LOCK,POST_NOTIFICATIONS,RECEIVE_BOOT_COMPLETED

# Фоновый сервис
android.services = MeshService:src/mesh_service.py:foreground:sticky

# Архитектуры
android.archs = arm64-v8a, armeabi-v7a

# Логирование
android.logcat_filters = *:S python:D

# Размер кучи JVM
android.gradle_options = org.gradle.jvmargs=-Xmx4096m

# p4a (python-for-android) настройки
# Используем стабильную ветку
p4a.branch = master

# [buildozer]
log_level = 2
build_dir = ./.buildozer
bin_dir = ./bin
