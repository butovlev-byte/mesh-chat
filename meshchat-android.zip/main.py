"""MeshChat — точка входа приложения с Android-интеграцией."""
import asyncio
import sys
import os
import platform

# Добавляем src в путь
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Определение платформы
IS_ANDROID = 'ANDROID_ARGUMENT' in os.environ
IS_DESKTOP = not IS_ANDROID

from kivy.config import Config
Config.set("graphics", "width", "400")
Config.set("graphics", "height", "700")
Config.set("graphics", "resizable", False)

from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager, FadeTransition
from kivy.clock import Clock, mainthread
from kivy.properties import ObjectProperty, BooleanProperty
from kivy.app import App

from kivymd.app import MDApp
from kivymd.uix.screen import MDScreen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.navigationdrawer import MDNavigationDrawer
from kivymd.uix.list import OneLineListItem, MDList
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.label import MDLabel
from kivymd.uix.dialog import MDDialog
from kivymd.uix.button import MDFlatButton

from crypto_utils import CryptoManager
from database import Database
from mesh_network import MeshNetwork
from messaging import MessagingService

from ui.contacts_screen import ContactsScreen
from ui.chat_screen import ChatScreen
from ui.settings_screen import SettingsScreen

# Android-специфичные импорты
if IS_ANDROID:
    try:
        from android_contacts import get_phone_contacts, request_contacts_permission
        from android_notifications import show_notification, request_notification_permission
        from jnius import autoclass
        from android.runnable import run_on_ui_thread
    except ImportError as e:
        print(f"[App] Ошибка импорта Android-модулей: {e}")
        IS_ANDROID = False

KV = """
BoxLayout:
    orientation: "vertical"

    MDTopAppBar:
        id: top_bar
        title: "MeshChat"
        elevation: 4
        left_action_items: [["menu", lambda x: nav_drawer.set_state("open")]]

    ScreenManager:
        id: screen_manager
        transition: FadeTransition(duration=0.2)

    MDNavigationDrawer:
        id: nav_drawer
        radius: (0, 16, 16, 0)

        MDBoxLayout:
            orientation: "vertical"
            padding: "8dp"
            spacing: "8dp"

            MDLabel:
                text: "MeshChat"
                font_style: "H6"
                size_hint_y: None
                height: self.texture_size[1]
                padding: "16dp", "16dp"

            MDLabel:
                text: "P2P Messenger"
                font_style: "Caption"
                theme_text_color: "Secondary"
                size_hint_y: None
                height: self.texture_size[1]
                padding: "16dp", 0

            MDSeparator:

            ScrollView:
                MDList:
                    OneLineListItem:
                        text: "Контакты"
                        on_release:
                            app.switch_screen("contacts")
                            nav_drawer.set_state("close")

                    OneLineListItem:
                        text: "Настройки"
                        on_release:
                            app.switch_screen("settings")
                            nav_drawer.set_state("close")

                    OneLineListItem:
                        text: "О приложении"
                        on_release:
                            app.show_about()
                            nav_drawer.set_state("close")
"""


class MeshChatApp(MDApp):
    """Главное приложение MeshChat."""

    crypto = ObjectProperty(None)
    mesh = ObjectProperty(None)
    messaging = ObjectProperty(None)
    db = ObjectProperty(None)
    is_android = BooleanProperty(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.is_android = IS_ANDROID
        self._network_thread = None
        self._pending_permissions = []

    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "DeepPurple"
        self.theme_cls.accent_palette = "Teal"

        # Инициализация подсистем
        self._init_core()

        # UI
        self.root = Builder.load_string(KV)
        self.screen_manager = self.root.ids.screen_manager
        self._init_screens()

        # Запрос Android-разрешений
        if self.is_android:
            Clock.schedule_once(self._request_android_permissions, 0.5)

        # Запуск mesh-сети
        Clock.schedule_once(self._start_network, 1)

        # Проверка intent при запуске (для открытия чата из уведомления)
        if self.is_android:
            Clock.schedule_once(self._check_intent, 1.5)

        return self.root

    def _init_core(self):
        """Инициализация крипто, БД и сети."""
        self.crypto = CryptoManager()
        self.db = Database()
        self.mesh = MeshNetwork(self.crypto.node_id, self.crypto)
        self.messaging = MessagingService(self.crypto, self.mesh, self.db)

        # Подписка на входящие сообщения
        self.mesh.add_message_callback(self._on_message_received)

        print(f"[App] Node ID: {self.crypto.node_id}")
        print(f"[App] Платформа: {'Android' if self.is_android else 'Desktop'}")

    def _init_screens(self):
        """Создание экранов."""
        contacts = ContactsScreen(name="contacts")
        contacts.messaging = self.messaging
        contacts.app = self
        self.screen_manager.add_widget(contacts)

        chat = ChatScreen(name="chat")
        chat.messaging = self.messaging
        self.screen_manager.add_widget(chat)

        settings = SettingsScreen(name="settings")
        settings.crypto = self.crypto
        settings.mesh = self.mesh
        settings.app = self
        self.screen_manager.add_widget(settings)

        self.screen_manager.current = "contacts"

    def _request_android_permissions(self, dt):
        """Запрос всех необходимых Android-разрешений."""
        if not self.is_android:
            return

        try:
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            activity = PythonActivity.mActivity
            PackageManager = autoclass('android.content.pm.PackageManager')
            PERMISSION_GRANTED = PackageManager.PERMISSION_GRANTED

            permissions = [
                "android.permission.READ_CONTACTS",
                "android.permission.BLUETOOTH_SCAN",
                "android.permission.BLUETOOTH_CONNECT",
                "android.permission.BLUETOOTH_ADVERTISE",
                "android.permission.ACCESS_FINE_LOCATION",
                "android.permission.ACCESS_COARSE_LOCATION",
                "android.permission.POST_NOTIFICATIONS",
                "android.permission.FOREGROUND_SERVICE",
                "android.permission.WAKE_LOCK",
            ]

            # Проверяем какие разрешения уже есть
            missing = []
            for perm in permissions:
                if activity.checkSelfPermission(perm) != PERMISSION_GRANTED:
                    missing.append(perm)

            if missing:
                print(f"[App] Запрос разрешений: {len(missing)} шт.")
                activity.requestPermissions(missing, 1001)
            else:
                print("[App] Все разрешения уже предоставлены")

        except Exception as e:
            print(f"[App] Ошибка запроса разрешений: {e}")

    def _check_intent(self, dt):
        """Проверить intent при запуске (открытие из уведомления)."""
        if not self.is_android:
            return

        try:
            PythonActivity = autoclass('org.kivy.android.PythonActivity')
            activity = PythonActivity.mActivity
            intent = activity.getIntent()

            contact_id = intent.getStringExtra("contact_id")
            open_chat = intent.getBooleanExtra("open_chat", False)

            if contact_id and open_chat:
                print(f"[App] Открытие чата из уведомления: {contact_id}")
                self._open_chat_by_id(contact_id)

        except Exception as e:
            print(f"[App] Ошибка проверки intent: {e}")

    def _open_chat_by_id(self, contact_id: str):
        """Открыть чат с контактом по ID."""
        chat_screen = self.screen_manager.get_screen("chat")
        if chat_screen:
            chat_screen.set_contact(contact_id)
            self.switch_screen("chat")

    def _start_network(self, dt):
        """Запуск mesh-сети в фоновом потоке."""
        import threading
        self._network_thread = threading.Thread(
            target=self._run_async_loop, 
            daemon=True
        )
        self._network_thread.start()
        print("[App] Mesh-сеть запущена")

    def _run_async_loop(self):
        """Собственный asyncio event loop для mesh-сети."""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        async def main():
            await asyncio.gather(
                self.mesh.start_server(),
                self.mesh.start_discovery(),
                self.mesh.start_bluetooth_server(),
            )

        try:
            loop.run_until_complete(main())
        except Exception as e:
            print(f"[App] Network error: {e}")
        finally:
            loop.close()

    @mainthread
    def _on_message_received(self, msg, from_addr):
        """Обработчик входящих сообщений (в UI-потоке)."""
        # Обновляем UI
        contacts_screen = self.screen_manager.get_screen("contacts")
        if contacts_screen:
            contacts_screen.refresh_contacts()

        # Показываем уведомление если приложение не активно или сообщение не для текущего чата
        if self.is_android:
            current_screen = self.screen_manager.current
            chat_screen = self.screen_manager.get_screen("chat")

            show_notif = (
                current_screen != "chat" or 
                (chat_screen and getattr(chat_screen, 'current_contact_id', None) != msg.sender_id)
            )

            if show_notif and msg.recipient_id == self.crypto.node_id:
                contact = self.db.get_contact(msg.sender_id)
                display_name = contact["display_name"] if contact else f"Peer_{msg.sender_id[:6]}"

                show_notification(
                    f"Новое сообщение от {display_name}",
                    msg.content[:100] if msg.content else "Зашифрованное сообщение",
                    msg.sender_id
                )

    def sync_phone_contacts(self) -> list:
        """Синхронизация с телефонной книгой Android."""
        if not self.is_android:
            print("[App] Синхронизация контактов только на Android")
            return []

        try:
            request_contacts_permission()
            phone_contacts = get_phone_contacts()

            synced = 0
            for contact in phone_contacts:
                # Проверяем, есть ли уже в mesh-контактах по номеру телефона
                existing = self.db.find_contact_by_phone(contact["phone"])

                if not existing:
                    self.db.add_contact(
                        node_id=None,
                        display_name=contact["name"],
                        phone_number=contact["phone"],
                        contact_id=contact.get("contact_id")
                    )
                    synced += 1
                else:
                    # Обновляем имя если изменилось
                    self.db.update_contact_name(
                        contact_id=existing["id"],
                        display_name=contact["name"]
                    )

            print(f"[App] Синхронизировано {synced} новых контактов")
            return phone_contacts

        except Exception as e:
            print(f"[App] Ошибка синхронизации контактов: {e}")
            return []

    def switch_screen(self, name: str):
        """Переключение экрана."""
        if self.screen_manager.has_screen(name):
            self.screen_manager.current = name

    def show_about(self):
        """Диалог 'О приложении'."""
        dialog = MDDialog(
            title="О MeshChat",
            text=(
                "🔗 MeshChat v1.0\n"
                "Децентрализованный P2P мессенджер\n\n"
                "• Mesh-сеть через Wi-Fi/Bluetooth\n"
                "• ECIES шифрование\n"
                "• Доступ к телефонной книге\n"
                "• Push-уведомления\n"
                "• Без серверов и интернета"
            ),
            buttons=[MDFlatButton(text="Закрыть", on_release=lambda x: dialog.dismiss())],
        )
        dialog.open()

    def on_stop(self):
        """При закрытии приложения."""
        if self.mesh:
            self.mesh.stop()
        print("[App] MeshChat остановлен")


if __name__ == "__main__":
    MeshChatApp().run()
