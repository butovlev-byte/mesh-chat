[app]
# Название приложения
title = MeshChat

# Имя пакета
package.name = meshchat

# Домен пакета (должен быть уникальным)
package.domain = org.meshchat

# Исходная директория
source.dir = src

# Расширения файлов для включения
source.include_exts = py,png,jpg,kv,atlas,ttf,json,txt,xml

# Версия приложения
version = 1.0.0

# Требования (зависимости)
requirements = python3,kivy==2.3.0,kivymd==1.2.0,pyjnius,bleak,cryptography,pycryptodome,sqlite3,asyncio,uuid,json,typing,dataclasses,threading,time,socket,hashlib

# Иконка приложения
# icon.filename = %(source.dir)s/assets/icon.png

# Заставка (splash screen)
# presplash.filename = %(source.dir)s/assets/presplash.png

# Ориентация
orientation = portrait

# Полноэкранный режим
fullscreen = 0

# Android API
android.api = 33
android.minapi = 21
android.sdk = 33
android.ndk = 25b

# Разрешения Android (КРИТИЧЕСКИ ВАЖНО!)
# READ_CONTACTS — доступ к телефонной книге
# POST_NOTIFICATIONS — push-уведомления (Android 13+)
# BLUETOOTH_SCAN, BLUETOOTH_CONNECT, BLUETOOTH_ADVERTISE — Bluetooth mesh
# ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION — Wi-Fi Direct / Bluetooth discovery
# FOREGROUND_SERVICE — фоновая работа
# WAKE_LOCK — предотвращение засыпания при mesh-сети
# INTERNET — для тестирования на эмуляторе
# READ_PHONE_STATE — для получения IMEI/идентификатора устройства
android.permissions = INTERNET,BLUETOOTH,BLUETOOTH_ADMIN,BLUETOOTH_SCAN,BLUETOOTH_CONNECT,BLUETOOTH_ADVERTISE,ACCESS_FINE_LOCATION,ACCESS_COARSE_LOCATION,READ_CONTACTS,READ_PHONE_STATE,FOREGROUND_SERVICE,WAKE_LOCK,POST_NOTIFICATIONS,RECEIVE_BOOT_COMPLETED

# Фоновый сервис (для mesh-сети в фоне)
# Сервис будет запускаться при старте приложения и продолжать работать
android.services = MeshService:mesh_service.py:foreground:sticky

# Дополнительные Java-классы (если нужны)
# android.add_src =

# Дополнительные библиотеки
# android.add_libs_arm64_v8a =
# android.add_libs_armeabi_v7a =

# AAB (Android App Bundle) для Google Play
# android.release_artifact = aab

# Оптимизация
android.archs = arm64-v8a, armeabi-v7a

# Логирование
android.logcat_filters = *:S python:D

# Размер кучи JVM
android.gradle_options = org.gradle.jvmargs=-Xmx4096m

# [buildozer]
# Лог файл
log_level = 2

# Директория для сборки
build_dir = ./.buildozer

# Директория для bin
bin_dir = ./bin
