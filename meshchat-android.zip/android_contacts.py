"""Доступ к телефонной книге Android через Pyjnius."""
import os
from typing import List, Dict, Optional

IS_ANDROID = 'ANDROID_ARGUMENT' in os.environ

if IS_ANDROID:
    from jnius import autoclass


def get_phone_contacts() -> List[Dict[str, str]]:
    """Получение всех контактов из телефонной книги Android.

    Returns:
        Список словарей с ключами 'name' и 'phone'.
    """
    if not IS_ANDROID:
        return []

    try:
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mActivity

        ContentResolver = autoclass('android.content.ContentResolver')
        ContactsContract = autoclass('android.provider.ContactsContract')

        resolver = activity.getContentResolver()
        cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            None, None, None, None
        )

        contacts = []
        if cursor:
            name_idx = cursor.getColumnIndex(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
            )
            phone_idx = cursor.getColumnIndex(
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            contact_id_idx = cursor.getColumnIndex(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID
            )

            while cursor.moveToNext():
                name = cursor.getString(name_idx)
                phone = cursor.getString(phone_idx)
                contact_id = cursor.getString(contact_id_idx)

                if name and phone:
                    # Нормализация номера телефона
                    phone_clean = phone.replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
                    contacts.append({
                        "name": name,
                        "phone": phone_clean,
                        "contact_id": contact_id
                    })

            cursor.close()

        return contacts
    except Exception as e:
        print(f"[AndroidContacts] Ошибка получения контактов: {e}")
        return []


def get_contact_photo_uri(contact_id: str) -> Optional[str]:
    """Получить URI фото контакта."""
    if not IS_ANDROID:
        return None

    try:
        ContactsContract = autoclass('android.provider.ContactsContract')
        return str(ContactsContract.Contacts.CONTENT_URI) + "/" + contact_id + "/photo"
    except Exception as e:
        print(f"[AndroidContacts] Ошибка получения фото: {e}")
        return None


def request_contacts_permission() -> bool:
    """Запросить разрешение на чтение контактов.

    Returns:
        True если разрешение уже есть или запрошено.
    """
    if not IS_ANDROID:
        return False

    try:
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mActivity

        # Проверяем текущее разрешение
        PackageManager = autoclass('android.content.pm.PackageManager')
        PERMISSION_GRANTED = PackageManager.PERMISSION_GRANTED

        has_perm = activity.checkSelfPermission(
            "android.permission.READ_CONTACTS"
        ) == PERMISSION_GRANTED

        if not has_perm:
            activity.requestPermissions(
                ["android.permission.READ_CONTACTS"], 1001
            )

        return True
    except Exception as e:
        print(f"[AndroidContacts] Ошибка запроса разрешения: {e}")
        return False
