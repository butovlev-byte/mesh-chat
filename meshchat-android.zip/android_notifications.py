"""Android push-уведомления через Pyjnius."""
import os
from typing import Optional

IS_ANDROID = 'ANDROID_ARGUMENT' in os.environ

if IS_ANDROID:
    from jnius import autoclass


def show_notification(
    title: str, 
    message: str, 
    contact_id: Optional[str] = None,
    notification_id: int = None
) -> bool:
    """Показать Android-уведомление.

    Args:
        title: Заголовок уведомления
        message: Текст сообщения
        contact_id: ID контакта для открытия чата при тапе
        notification_id: Уникальный ID уведомления (если None — генерируется из title)

    Returns:
        True если уведомление показано успешно
    """
    if not IS_ANDROID:
        print(f"[Notification] {title}: {message}")
        return False

    try:
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mActivity
        context = activity.getApplicationContext()

        NotificationBuilder = autoclass('android.app.Notification$Builder')
        NotificationManager = autoclass('android.app.NotificationManager')
        Intent = autoclass('android.content.Intent')
        PendingIntent = autoclass('android.app.PendingIntent')

        # Intent для открытия приложения по тапу
        intent = Intent(context, PythonActivity)
        intent.setFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP | 
            Intent.FLAG_ACTIVITY_SINGLE_TOP |
            Intent.FLAG_ACTIVITY_NEW_TASK
        )

        if contact_id:
            intent.putExtra("contact_id", contact_id)
            intent.putExtra("open_chat", True)

        # PendingIntent для запуска активности
        pending_intent = PendingIntent.getActivity(
            context, 
            0, 
            intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        )

        # Создание канала уведомлений (Android 8+)
        try:
            NotificationChannel = autoclass('android.app.NotificationChannel')
            channel_id = "meshchat_messages"
            channel = NotificationChannel(
                channel_id,
                "MeshChat Messages",
                NotificationManager.IMPORTANCE_HIGH
            )
            channel.setDescription("Входящие сообщения MeshChat")
            channel.enableVibration(True)
            channel.setVibrationPattern([0, 500, 200, 500])

            notification_manager = context.getSystemService(
                context.NOTIFICATION_SERVICE
            )
            notification_manager.createNotificationChannel(channel)
        except Exception:
            channel_id = None  # Для Android < 8

        # Создание уведомления
        if channel_id:
            builder = NotificationBuilder(context, channel_id)
        else:
            builder = NotificationBuilder(context)

        builder.setContentTitle(title)
        builder.setContentText(message)
        builder.setSmallIcon(context.getApplicationInfo().icon)
        builder.setContentIntent(pending_intent)
        builder.setAutoCancel(True)
        builder.setPriority(NotificationBuilder.PRIORITY_HIGH)
        builder.setDefaults(NotificationBuilder.DEFAULT_ALL)

        # Генерация ID уведомления
        if notification_id is None:
            notification_id = hash(contact_id or title) % 10000

        notification_manager.notify(notification_id, builder.build())
        return True

    except Exception as e:
        print(f"[Notification] Ошибка показа уведомления: {e}")
        return False


def cancel_notification(notification_id: int) -> bool:
    """Отменить уведомление по ID."""
    if not IS_ANDROID:
        return False

    try:
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        context = PythonActivity.mActivity.getApplicationContext()
        NotificationManager = autoclass('android.app.NotificationManager')

        notification_manager = context.getSystemService(
            context.NOTIFICATION_SERVICE
        )
        notification_manager.cancel(notification_id)
        return True
    except Exception as e:
        print(f"[Notification] Ошибка отмены уведомления: {e}")
        return False


def request_notification_permission() -> bool:
    """Запросить разрешение на отправку уведомлений (Android 13+)."""
    if not IS_ANDROID:
        return False

    try:
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        activity = PythonActivity.mActivity

        PackageManager = autoclass('android.content.pm.PackageManager')
        PERMISSION_GRANTED = PackageManager.PERMISSION_GRANTED

        has_perm = activity.checkSelfPermission(
            "android.permission.POST_NOTIFICATIONS"
        ) == PERMISSION_GRANTED

        if not has_perm:
            activity.requestPermissions(
                ["android.permission.POST_NOTIFICATIONS"], 1002
            )

        return True
    except Exception as e:
        print(f"[Notification] Ошибка запроса разрешения: {e}")
        return False
