# MeshChat — Android сборка

## Требования

- Python 3.8+
- Buildozer
- Android SDK/NDK (устанавливается автоматически через buildozer)
- Linux/macOS (Windows — через WSL2)

## Установка зависимостей

```bash
pip install buildozer cython
```

## Структура файлов для Android

Скопируйте эти файлы в ваш репозиторий:

```
src/
├── main.py                    ← Обновлённый (Android-интеграция)
├── mesh_network.py            ← Обновлённый (Bluetooth для Android)
├── mesh_service.py            ← Новый (фоновый сервис)
├── android_contacts.py        ← Новый (доступ к телефонной книге)
├── android_notifications.py   ← Новый (push-уведомления)
├── contacts_screen.py         ← Обновлённый (синхронизация контактов)
└── ... (остальные файлы без изменений)

buildozer.spec                  ← Новый (конфигурация сборки)
```

## Сборка APK

```bash
# Перейдите в корень проекта
cd mesh-chat

# Скопируйте buildozer.spec
# Скопируйте все файлы из src/

# Первая сборка (загрузит SDK/NDK, ~30 минут)
buildozer android debug

# Быстрая пересборка
buildozer android debug deploy run
```

APK будет в `bin/meshchat-1.0.0-arm64-v8a_armeabi-v7a-debug.apk`

## Установка на устройство

```bash
# Через buildozer
buildozer android deploy run

# Или вручную
adb install bin/meshchat-1.0.0-arm64-v8a_armeabi-v7a-debug.apk
```

## Разрешения Android

При первом запуске приложение запросит:
- **Контакты** — для синхронизации телефонной книги
- **Bluetooth** — для mesh-сети через Bluetooth
- **Локация** — для Wi-Fi Direct / Bluetooth discovery (требуется Android)
- **Уведомления** — для push-уведомлений о сообщениях

## Функции Android-версии

✅ Доступ к телефонной книге устройства  
✅ Push-уведомления о входящих сообщениях  
✅ Bluetooth mesh (обнаружение + передача)  
✅ Фоновая работа mesh-сети (через сервис)  
✅ Открытие чата из уведомления  
✅ Синхронизация имён контактов  

## Отладка

```bash
# Логи устройства
adb logcat -s python:D

# Логи через buildozer
buildozer android logcat
```

## Известные проблемы

1. **Bluetooth на Android 12+** — требуются разрешения BLUETOOTH_SCAN и BLUETOOTH_CONNECT
2. **Фоновый сервис** — может быть убит системой при нехватке памяти (добавлен sticky)
3. **Wi-Fi Direct** — требует включённого Wi-Fi и может не работать на некоторых устройствах

## Лицензия

MIT
