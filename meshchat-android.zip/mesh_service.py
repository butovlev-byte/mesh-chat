"""Фоновый сервис MeshChat для Android.

Этот сервис запускается при старте приложения и продолжает работать
даже когда приложение свёрнуто, обеспечивая приём сообщений и уведомления.
"""
import os
import sys
import asyncio
import time
import threading

# Добавляем src в путь
service_dir = os.path.dirname(os.path.abspath(__file__))
if service_dir not in sys.path:
    sys.path.insert(0, service_dir)

IS_ANDROID = 'ANDROID_ARGUMENT' in os.environ

if IS_ANDROID:
    from jnius import autoclass
    PythonService = autoclass('org.kivy.android.PythonService')

from crypto_utils import CryptoManager
from database import Database
from mesh_network import MeshNetwork, MeshMessage
from messaging import MessagingService


def show_notification(title: str, message: str, contact_id: str = None):
    """Показать уведомление из фонового сервиса."""
    if not IS_ANDROID:
        print(f"[Service] {title}: {message}")
        return

    try:
        from android_notifications import show_notification as _show
        _show(title, message, contact_id)
    except Exception as e:
        print(f"[Service] Не удалось показать уведомление: {e}")


def on_background_message(msg: MeshMessage, service_context=None):
    """Обработчик входящих сообщений в фоновом режиме."""
    try:
        # Сохраняем в БД
        db = Database()
        db.save_message(
            msg_id=msg.msg_id,
            sender_id=msg.sender_id,
            recipient_id=msg.recipient_id,
            content=msg.content,
            encrypted_payload=str(msg.encrypted_payload) if msg.encrypted_payload else None,
            signature=msg.signature,
            hops=msg.hops,
            ttl=msg.ttl,
        )

        # Показываем уведомление только если сообщение для нас
        if msg.recipient_id and msg.content:
            # Получаем имя контакта из БД
            contact = db.get_contact(msg.sender_id)
            display_name = contact["display_name"] if contact else f"Peer_{msg.sender_id[:6]}"

            show_notification(
                f"Новое сообщение от {display_name}",
                msg.content[:100],
                msg.sender_id
            )

        # Обновляем heartbeat контакта
        if msg.msg_type == "heartbeat":
            db.update_node(
                node_id=msg.sender_id,
                ip_address=None,  # IP неизвестен в фоне
            )

    except Exception as e:
        print(f"[Service] Ошибка обработки сообщения: {e}")


def main():
    """Главная функция фонового сервиса."""
    print("[Service] MeshChat фоновый сервис запущен")

    # Инициализация подсистем
    try:
        crypto = CryptoManager()
        db = Database()
        mesh = MeshNetwork(crypto.node_id, crypto)
        messaging = MessagingService(crypto, mesh, db)

        # Подписываемся на сообщения
        mesh.add_message_callback(on_background_message)

        print(f"[Service] Node ID: {crypto.node_id}")

        # Запускаем mesh-сеть
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        async def run_mesh():
            await asyncio.gather(
                mesh.start_server(),
                mesh.start_discovery(),
                mesh.start_bluetooth_server(),
            )

        loop.run_until_complete(run_mesh())
        loop.run_forever()

    except Exception as e:
        print(f"[Service] Критическая ошибка: {e}")
        time.sleep(5)
        # Перезапуск при ошибке
        main()


if __name__ == '__main__':
    main()
