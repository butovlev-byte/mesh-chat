"""Экран контактов с поддержкой Android телефонной книги."""
from kivy.properties import ObjectProperty
from kivy.clock import Clock
from kivymd.uix.screen import MDScreen
from kivymd.uix.list import TwoLineListItem, OneLineIconListItem, MDList
from kivymd.uix.button import MDFloatingActionButton, MDRaisedButton
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.dialog import MDDialog
from kivymd.uix.textfield import MDTextField
from kivymd.uix.button import MDFlatButton
from kivymd.app import MDApp
import os

IS_ANDROID = 'ANDROID_ARGUMENT' in os.environ


class ContactsScreen(MDScreen):
    """Экран списка контактов."""

    messaging = ObjectProperty(None)
    app = ObjectProperty(None)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dialog = None

    def on_enter(self):
        """При входе на экран — обновляем список."""
        self.load_contacts()

    def load_contacts(self):
        """Загрузка и отображение контактов."""
        self.ids.contacts_list.clear_widgets()

        if not self.messaging:
            return

        contacts = self.messaging.get_contacts()

        if not contacts:
            # Показываем подсказку
            from kivymd.uix.label import MDLabel
            label = MDLabel(
                text="Нет контактов.\nДобавьте контакт или синхронизируйте с телефоном.",
                halign="center",
                theme_text_color="Secondary"
            )
            self.ids.contacts_list.add_widget(label)
            return

        for contact in contacts:
            # Определяем статус
            status = "В сети" if contact.get("online") else "Оффлайн"
            if contact.get("phone_number"):
                status += f" • {contact['phone_number']}"

            item = TwoLineListItem(
                text=contact.get("display_name", f"Peer_{contact.get('node_id', 'unknown')[:6]}"),
                secondary_text=status,
                on_release=lambda x, c=contact: self.open_chat(c)
            )
            self.ids.contacts_list.add_widget(item)

    def refresh_contacts(self):
        """Принудительное обновление списка (вызывается извне)."""
        Clock.schedule_once(lambda dt: self.load_contacts(), 0)

    def open_chat(self, contact: dict):
        """Открыть чат с контактом."""
        chat_screen = self.manager.get_screen("chat")
        if chat_screen:
            chat_screen.set_contact(contact)
            self.manager.current = "chat"

    def show_add_contact_dialog(self):
        """Диалог добавления нового контакта."""
        if not self.dialog:
            self.dialog = MDDialog(
                title="Добавить контакт",
                type="custom",
                content_cls=MDBoxLayout(
                    MDTextField(
                        id="contact_name",
                        hint_text="Имя контакта",
                        helper_text="Как отображать в списке",
                    ),
                    MDTextField(
                        id="contact_pubkey",
                        hint_text="Публичный ключ",
                        helper_text="PEM формат или Node ID",
                        multiline=True,
                    ),
                    orientation="vertical",
                    spacing="12dp",
                    size_hint_y=None,
                    height="200dp",
                ),
                buttons=[
                    MDFlatButton(
                        text="Отмена",
                        theme_text_color="Custom",
                        text_color=self.theme_cls.primary_color,
                        on_release=lambda x: self.dialog.dismiss()
                    ),
                    MDFlatButton(
                        text="Добавить",
                        theme_text_color="Custom",
                        text_color=self.theme_cls.primary_color,
                        on_release=self._add_contact
                    ),
                ],
            )
        self.dialog.open()

    def _add_contact(self, *args):
        """Добавление контакта из диалога."""
        content = self.dialog.content_cls
        name_field = content.ids.contact_name
        pubkey_field = content.ids.contact_pubkey

        name = name_field.text.strip()
        pubkey = pubkey_field.text.strip()

        if name and pubkey:
            self.messaging.db.add_contact(
                node_id=pubkey[:32] if len(pubkey) > 32 else pubkey,
                display_name=name,
                public_key=pubkey if "BEGIN PUBLIC KEY" in pubkey else None
            )
            self.load_contacts()
            self.dialog.dismiss()
            name_field.text = ""
            pubkey_field.text = ""

    def sync_phone_contacts(self):
        """Синхронизация с телефонной книгой Android."""
        if not IS_ANDROID:
            from kivymd.uix.snackbar import MDSnackbar
            MDSnackbar(
                text="Синхронизация доступна только на Android"
            ).open()
            return

        if not self.app:
            return

        # Показываем индикатор загрузки
        from kivymd.uix.snackbar import MDSnackbar
        snackbar = MDSnackbar(text="Синхронизация контактов...")
        snackbar.open()

        # Запускаем синхронизацию в отдельном потоке
        import threading
        def sync():
            contacts = self.app.sync_phone_contacts()
            Clock.schedule_once(
                lambda dt: self._on_sync_complete(len(contacts)), 
                0
            )

        threading.Thread(target=sync, daemon=True).start()

    def _on_sync_complete(self, count: int):
        """Callback завершения синхронизации."""
        from kivymd.uix.snackbar import MDSnackbar
        MDSnackbar(
            text=f"Синхронизировано {count} контактов"
        ).open()
        self.load_contacts()


KV_CONTACTS = """
<ContactsScreen>:
    MDBoxLayout:
        orientation: "vertical"

        ScrollView:
            MDList:
                id: contacts_list

        MDFloatingActionButton:
            icon: "plus"
            pos_hint: {"right": 0.95, "y": 0.05}
            on_release: root.show_add_contact_dialog()

        MDFloatingActionButton:
            icon: "sync"
            pos_hint: {"right": 0.75, "y": 0.05}
            on_release: root.sync_phone_contacts()
            md_bg_color: app.theme_cls.accent_color
"""
