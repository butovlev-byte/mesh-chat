[app]
# Название приложения
title = MeshChat

# Имя пакета
package.name = meshchat

# Домен пакета
package.domain = org.meshchat

# Исходная директория
source.dir = src

# Расширения файлов
source.include_exts = py,png,jpg,kv,atlas,ttf,json,txt,xml

# Версия
version = 1.0.0

# Зависимости
requirements = python3,kivy==2.3.0,kivymd==1.2.0,pyjnius,bleak,cryptography,pycryptodome

# Ориентация
orientation = portrait
fullscreen = 0

# Android API (используем android.api вместо android.sdk)
android.api = 33
android.minapi = 21

# Разрешения
android.permissions = INTERNET,BLUETOOTH,BLUETOOTH_ADMIN,BLUETOOTH_SCAN,BLUETOOTH_CONNECT,BLUETOOTH_ADVERTISE,ACCESS_FINE_LOCATION,ACCESS_COARSE_LOCATION,READ_CONTACTS,READ_PHONE_STATE,FOREGROUND_SERVICE,WAKE_LOCK,POST_NOTIFICATIONS,RECEIVE_BOOT_COMPLETED

# Фоновый сервис
android.services = MeshService:src/mesh_service.py:foreground:sticky

# Архитектуры (новый формат)
android.archs = arm64-v8a, armeabi-v7a

# Логирование
android.logcat_filters = *:S python:D

# p4a
p4a.branch = master

# [buildozer]
log_level = 2
build_dir = ./.buildozer
bin_dir = ./bin
